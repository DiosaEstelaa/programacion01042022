package programacion010422;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Scanner;

public class MiniFileManager {
    
/*

Completa tu miniTerminal, para que ofrezca el comando info.
El comando info recibe como argumento una ruta y muestra por pantalla el tamaño
en bytes y megas de la ruta, así como la fecha de su última modificación.
Funciona tanto para archivos como para carpetas.
Debe indicar si la ruta no existe y manejarse excepciones.
Observa en la captura como el comando info muestra el tamaño de la carpeta
target, incluyendo el tamaño de los archivos o subcarpetas que almacena.

*/


    public MiniFileManager() {
    }
    
    ////////////////////////////////////////////////////////////////////////////
    //info: El comando info recibe como argumento una ruta y muestra por pantalla el tamaño 
    //en bytes y megas de la ruta, así como la fecha de su última modificación.
    //---------------------------------------
    public  static void info(File ficherooo) throws FileNotFoundException{
        
        long ultimaMod2 = ficherooo.lastModified();
        
        Date fechaaa = new Date(ultimaMod2);

        double megas = ficherooo.length();
        
        if (ficherooo.exists()) {
            
             System.out.println("La ruta es: " + ficherooo.getPath());
        
        String ruta = ficherooo.getAbsolutePath();
        
        
        if (ficherooo.isDirectory()) {
            File[] vectorArchivos = ficherooo.listFiles();

            for (int i = 0; i < vectorArchivos.length; i++) {

                File f = vectorArchivos[i];

                if (f.isDirectory()) {
                    System.out.println("*: " + f.getName());
                }
            }
            for (int t = 0; t < vectorArchivos.length; t++) {
                File o = vectorArchivos[t];
                if (o.isFile()) {
                    System.out.println("A: " + o.getName());
                }
            }
            
        } else{
            
            System.out.println("-------------------------------");
            
        }
        
        System.out.println("Última modificación (fecha): " + fechaaa);
        System.out.println("Tamaño del archivo en bytes: " + ruta.length() + " bytes"); 
        System.out.println("Tamaño del archivo en megas: " + (megas/1024000) + " Mb");
        
        
        }else{
            
        System.out.println("OJO: ¡¡No existe !!");

            
           
    }
        
 }


    ////////////////////////////////////////////////////////////////////////////
    //pwd: Muestra cual es la carpeta actual.
    //---------------------------------------
        public static void getPWD(File carpetaActual) throws NoExisteFichero{
        if (carpetaActual.exists())
        System.out.println("pwd: " + carpetaActual.getAbsolutePath());
        else throw new NoExisteFichero(carpetaActual);
    }

    ////////////////////////////////////////////////////////////////////////////
    //cd: Cambia la carpeta actual a ‘DIR’. Con .. cambia a la carpeta superior.
    //-------------------------------------------------------------------------
    public static void cd(File carpetaActual, File DIR) {
            boolean cambiaDIR = carpetaActual.renameTo(DIR);
            System.out.println("Cambiamos a la carpeta DIR. " + cambiaDIR);
            System.out.println("cd .. \n"  + DIR.getParent());
    }

    ////////////////////////////////////////////////////////////////////////////
    //ls: Muestra la lista de directorios y archivos de la carpeta actual
    //-------------------------------------------------------------------
    public static void ls(File carpeta) throws Exception{
        if (carpeta.isDirectory()) {
            File[] vectorArchivos = carpeta.listFiles();

            for (int i = 0; i < vectorArchivos.length; i++) {

                File f = vectorArchivos[i];

                if (f.isDirectory()) {
                    System.out.println("*: " + f.getName());
                }
            }
            for (int t = 0; t < vectorArchivos.length; t++) {
                File o = vectorArchivos[t];
                if (o.isFile()) {
                    System.out.println("A: " + o.getName());
                }
            }
        } else {
            throw new FileNotFoundException("La ruta introducida no existe");
        }
    }
    ////////////////////////////////////////////////////////////////////////////
    //ll: Como ls pero muestra también el tamaño y la fecha de última modificación
    //----------------------------------------------------------
    public static void ll(File fichero){
        long ultimaMod = fichero.lastModified();
        Date fecha = new Date(ultimaMod);

        /*list()
        Returns an array of strings naming the files and directories in the directory denoted by this abstract pathname.*/
        //System.out.println(Arrays.toString(fichero.list()));
        System.out.println("Última modificación (ms) : " + ultimaMod);
        System.out.println("Última modificación (fecha): " + fecha);
        System.out.println("Tamaño del archivo: " + fichero.length()); //solo archivos
    }
    
    ////////////////////////////////////////////////////////////////////////////
    //mkdir <DIR>: Crea el directorio ‘DIR’ en la carpeta actual.
    //----------------------------------------------------------
    public static boolean mkdir(File directorioActual){
        System.out.println("Introduzca el nombre de la carpeta que quieres crear: ");
        Scanner reader = new Scanner(System.in);
        String nombreNuevaCarpeta = reader.nextLine();
        File nuevaCarpeta = new File(directorioActual.getAbsolutePath()+"//"+nombreNuevaCarpeta);
        boolean crearDirectorio = nuevaCarpeta.mkdir();
        return crearDirectorio;
    }
    
    ////////////////////////////////////////////////////////////////////////////
    //rm <FILE>: Borra ‘FILE’
    //------------------------
    public static void rm(File fichero) {
        if (fichero.isFile()) {
            boolean borrar = fichero.delete();
            System.out.println("Se ha podido borrar el archivo? " + borrar);
        } else if (fichero.isDirectory()) {
            File[] vectorArchivos = fichero.listFiles();
            boolean tieneSubcarpetas = false;

            for (File f : vectorArchivos){

                if (f.isDirectory()) {
                    tieneSubcarpetas = true;
                    System.out.println("No se puede borrar porque tiene subcarpetas. ");
                    break;
                }

            }if (!tieneSubcarpetas){
                for (int i = 0; i < vectorArchivos.length; i++) {
                    File f = vectorArchivos[i];
                    boolean borrar = f.delete();
                    System.out.println("Se borraron todos los archivos mi ciela. " + borrar);

                }

                boolean borrar2 = fichero.delete();
                System.out.println("La carpeta madre/padre se ha borrado. " +  borrar2);
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    //mv <FILE1> <FILE2>: Mueve o renombra ‘FILE1’ a ‘FILE2’.
    //------------------------------------------------------
    public static boolean mv(File rutaInicial, File rutaNueva){
    boolean renombrar = rutaInicial.renameTo(rutaNueva);
    return renombrar;
    }

    ////////////////////////////////////////////////////////////////////////////
    //help: Muestra una breve ayuda con los comandos disponibles
    //----------------------------------------------------------
    public static void help(){
        System.out.println(" ");
        System.out.println("pwd: Muestra cual es la carpeta actual.");
        System.out.println(" ");
        System.out.println("cd <DIR>: Cambia la carpeta actual a ‘DIR’. Con .. cambia a la carpeta superior.");
        System.out.println(" ");
        System.out.println("ls: Muestra la lista de directorios y archivos de la carpeta actual (primero directorios, luego\n" +
                "archivos, ambos ordenados alfabéticamente).");
        System.out.println(" ");
        System.out.println("ll: Como ls pero muestra también el tamaño y la fecha de última modificación.");
        System.out.println(" ");
        System.out.println("mkdir <DIR>: Crea el directorio ‘DIR’ en la carpeta actual.");
        System.out.println(" ");
        System.out.println("rm <FILE>: Borra ‘FILE’. Si es una carpeta, borrará primero sus archivos y luego la carpeta. Si\n" +
                "tiene subcarpetas, las dejará intactas y mostrará un aviso al usuario.");
        System.out.println(" ");
        System.out.println("mv <FILE1> <FILE2>: Mueve o renombra ‘FILE1’ a ‘FILE2’ ");
        System.out.println("info: El comando info recibe como argumento una ruta y muestra por pantalla el tamaño en bytes y megas de la ruta, así como la fecha de su última modificación. ");
    }

   
   
}
