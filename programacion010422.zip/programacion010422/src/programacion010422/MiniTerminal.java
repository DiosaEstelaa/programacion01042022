package programacion010422;

import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

/*

Completa tu miniTerminal, para que ofrezca el comando info.
El comando info recibe como argumento una ruta y muestra por pantalla el tamaño
en bytes y megas de la ruta, así como la fecha de su última modificación.
Funciona tanto para archivos como para carpetas.
Debe indicar si la ruta no existe y manejarse excepciones.
Observa en la captura como el comando info muestra el tamaño de la carpeta
target, incluyendo el tamaño de los archivos o subcarpetas que almacena.

*/

public class MiniTerminal {

    public static void main(String[] args) throws Exception {
        
        Scanner leer = new Scanner(System.in);
  
////////////////////////////////////////////////////////////////////////////////                

        File practica010422 = new File(" C:\\Users\\DAW\\Desktop\\programacion\\teoria\\ud5_Bucles_en_Java.pdf");

////////////////////////////////////////////////////////////////////////////////                
 
        File archivo1 = new File("C:\\Users\\DAW\\Desktop\\Documentos\\archivo1.odt");
        File archivo2 = new File("C:\\Users\\DAW\\Desktop\\Documentos\\archivo2.odt");
        File directorioActual = new File("C:\\Users\\DAW\\Desktop\\Documentos");
        File DIR = new File("C:\\Users\\DAW\\Desktop\\Documentos\\DIR");
        MiniFileManager fileManager = null;
        
        try {

            boolean bucleMenu = true;

            while (bucleMenu) { //primer while

                System.out.println("      ");
                System.out.println("Kè KIERE. ");
                System.out.println("   ");
                System.out.println("1-. pwd ");
                System.out.println("2-. cd <DIR> ");
                System.out.println("3-. ls ");
                System.out.println("4-. ll ");
                System.out.println("5-. mkdir <DIR> ");
                System.out.println("6-. rm <FILE> ");
                System.out.println("7-. mv <FILE1> <FILE2> ");
                System.out.println("8-. help ");
                
////////////////////////////////////////////////////////////////////////////////                

                System.out.println("9-. Info ");
                
////////////////////////////////////////////////////////////////////////////////   

                System.out.println("10-. salir.");
                System.out.println("   ");

                int opcion;

                while (!leer.hasNextInt()) { //segundo while

                    System.out.println("Error, introduce un número del '1' al '10' ");
                    leer.next(); 
                    
                } // fin segundo while
                
                opcion = leer.nextInt();


                switch (opcion) {
                    case 1:
                        System.out.println("----------------------------------------");
                        fileManager.getPWD(directorioActual);
                        break;
                        
                    case 2:
                        System.out.println("----------------------------------------");
                        fileManager.cd(directorioActual, DIR);
                        break;
                        
                    case 3:
                        System.out.println("----------------------------------------");
                        fileManager.ls(directorioActual);
                        break;
                        
                    case 4:
                        System.out.println("----------------------------------------");
                        fileManager.ll(directorioActual);
                        break;
                        
                    case 5:
                        System.out.println("----------------------------------------");
                        System.out.println(fileManager.mkdir(directorioActual) ? "Se ha creado correctamente" : "No se puede.");
                        break;
                        
                    case 6:
                        System.out.println("----------------------------------------");
                        fileManager.rm(archivo1);
                        break;
                        
                    case 7:
                        System.out.println("----------------------------------------");
                        System.out.println(fileManager.mv(archivo1, archivo2) ? "Se ha renombrado correctamente" : "No se puede.");
                        break;
                        
                    case 8:
                        System.out.println("----------------------------------------");
                        fileManager.help();
                        break;
                        
////////////////////////////////////////////////////////////////////////////////                
                        
                     case 9:
                        System.out.println("----------------------------------------");
                        fileManager.info(practica010422);
                        break;
                        
////////////////////////////////////////////////////////////////////////////////                
                        
                    case 10:
                        bucleMenu = false;
                        break;

                    default:
                        System.out.println(" ¬¬ Mal. Esta operacion no existe.");
                        
                } //fin switch

            } //fin primer while
            
        } catch (NoExisteFichero e) {
            System.err.println("Error: " + e.getMessage());
        }
        System.out.println("Sayorana beibiiiii ");

    } //fin main
} //fin public class
