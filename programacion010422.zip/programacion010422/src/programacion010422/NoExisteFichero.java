package programacion010422;

/*

Completa tu miniTerminal, para que ofrezca el comando info.
El comando info recibe como argumento una ruta y muestra por pantalla el tamaño
en bytes y megas de la ruta, así como la fecha de su última modificación.
Funciona tanto para archivos como para carpetas.
Debe indicar si la ruta no existe y manejarse excepciones.
Observa en la captura como el comando info muestra el tamaño de la carpeta
target, incluyendo el tamaño de los archivos o subcarpetas que almacena.

*/

import java.io.File;

public class NoExisteFichero extends Exception{
    File archivo;

    public NoExisteFichero(File archivo) {
        this.archivo = archivo;
    }
    public String toString(){
        return "Fichero no existe: " + this.archivo;
    }
}
